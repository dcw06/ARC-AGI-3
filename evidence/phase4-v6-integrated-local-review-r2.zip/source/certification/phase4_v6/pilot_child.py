"""Integrated pilot child roles. Live mode is gated before model imports."""
import argparse
import json
import os
from pathlib import Path
import time

from certification.phase4_v6.evidence import EvidenceStore
from certification.phase4_v6.live_probes import require_live_authority


def read(path):
    return json.loads(path.read_text())


def worker(args):
    store = EvidenceStore(args.output, 'worker')
    try:
        if args.mode == 'live':
            require_live_authority()
        if args.fault == 'worker':
            raise RuntimeError('injected worker failure')
        if args.fault == 'evidence':
            store.save('state.json', {'oversized': 'x' * (33*1024**2)})
        if args.fault == 'cancel':
            while not (args.output/'control/cancel.json').exists():
                time.sleep(.02)
            raise RuntimeError('injected worker acknowledged cancellation')
        from certification.phase4_v1.lifecycle import validate_freeze
        from certification.phase4_v6.worker import run_workload
        from certification.phase4_v1.local_probe import ScriptedCompletion
        from certification.phase4_v2.package import verify_environment_mount
        from arc_agi import Arcade, OperationMode
        from agent.framework_adapter import LocalFrameworkAdapter
        manifest = read(Path(__file__).resolve().parents[2]/'reports/phase4_v2_offline_package.json')
        verify_environment_mount(args.environments, manifest)
        _, rows = validate_freeze()
        service = None
        if args.mode == 'live':
            from certification.phase4_v6.service import SharedModelService
            service = SharedModelService(args.scratch)
            service.start()
        store.save('model-ready.json', {'model_inference': service is not None,
                                      'elapsed_seconds': time.monotonic()-args.started})
        def adapter(row):
            arcade = Arcade(operation_mode=OperationMode.OFFLINE,
                environments_dir=str(args.environments),
                recordings_dir=str(args.scratch/row['client_id']))
            return LocalFrameworkAdapter(arcade, seed_by_game={row['game_id']: row['environment_seed']})
        state = run_workload(rows, adapter,
            lambda row, watchdog: service or ScriptedCompletion('none', watchdog),
            args.output/'worker/state.json', args.output/'control/cancel.json',
            seconds=args.seconds, reserve=args.reserve, started=args.started,
            model_service=service, evidence_store=store)
        if state['status'] != 'complete' or state.get('error'):
            raise RuntimeError('worker did not complete')
    except Exception as exc:
        store.save('failure.json', {'error': type(exc).__name__+': '+str(exc)[:512]}, failure_receipt=True)
        raise


def monitor(args):
    from certification.phase4_v6.monitor import validate_binding, validate_sample, VRAM, RAM, SCRATCH
    from certification.phase4_v6.measurement import validate_telemetry
    store = EvidenceStore(args.output, 'monitor')
    state = {'scope': 'live_resource_monitor' if args.mode=='live' else 'injected_resource_monitor_not_target_evidence',
             'error': None, 'status': 'running', 'samples': [],
             'worker_pid': args.worker_pid, 'first_cell_monotonic': args.started,
             'ready_published': False, 'monitor_started_monotonic': time.monotonic()}
    state['monitor_started_seconds'] = state['monitor_started_monotonic']-args.started
    try:
        if args.mode == 'live':
            from certification.phase4_v6.live_probes import LiveResourceProbes
            probes = LiveResourceProbes(args.worker_pid, args.scratch)
            binding = probes.bind()
            sample, rss, scratch = probes.sample, probes.rss, probes.scratch
        else:
            from evaluation.phase4_runner import group_rss_bytes, tree_bytes
            fixture = {'uuid': 'GPU-INJECTED', 'name': 'RTX PRO 6000',
                       'used_bytes': 1, 'total_bytes': 96*1024**3}
            binding = {'gpu_uuid': fixture['uuid'], 'max_used_vram_bytes': VRAM, 'initial_telemetry': fixture}
            sample, rss, scratch = lambda *_: fixture, group_rss_bytes, lambda: tree_bytes(args.scratch)
        uuid = validate_binding(binding)
        state['gpu_binding'] = binding
        # Probe imports/binding are startup, not missing post-readiness samples.
        state['monitor_started_monotonic'] = time.monotonic()
        state['monitor_started_seconds'] = state['monitor_started_monotonic']-args.started
        previous = state['monitor_started_seconds']
        while True:
            if args.fault == 'monitor':
                raise RuntimeError('injected monitor failure')
            gpu = sample(uuid, VRAM); validate_sample(gpu, uuid)
            memory, disk = rss(args.worker_pid), scratch()
            now = time.monotonic()-args.started
            if (not 0 <= memory <= RAM or not 0 <= disk <= SCRATCH or now-previous > 1):
                raise ValueError('monitor resource or sampling-gap limit')
            state['samples'].append({'uuid': uuid, 'used_bytes': gpu['used_bytes'],
                'rss_bytes': memory, 'scratch_bytes': disk, 'elapsed_seconds': now,
                'monotonic_seconds': now+args.started})
            store.save('telemetry.json', state)
            previous = now
            if not state['ready_published']:
                store.save('ready.json', {'nonce': args.nonce, 'worker_pid': args.worker_pid,
                    'monitor_pid': os.getpid(), 'scope': state['scope'], 'gpu_binding': binding,
                    'sample': state['samples'][0]})
                state['ready_published'] = True
            if (args.output/'control/stop-monitor.json').exists():
                state['gpu_cleanup_verified'] = args.mode=='live' and not probes.gpu_processes()
                if args.mode=='live' and not state['gpu_cleanup_verified']:
                    raise RuntimeError('GPU processes remain after worker group cleanup')
                state['status'] = 'live_monitor_completed' if args.mode=='live' else 'injected_monitor_completed'
                break
            time.sleep(.25)
        state['monitor_ended_monotonic'] = time.monotonic()
        state['monitor_ended_seconds'] = state['monitor_ended_monotonic']-args.started
        state['samples_attempted'] = len(state['samples'])
        validate_telemetry(state['samples'], state['monitor_started_seconds'], state['monitor_ended_seconds'], uuid)
        store.save('telemetry.json', state)
        store.save('monitor-result.json', {k:v for k,v in state.items() if k!='samples'})
    except Exception as exc:
        store.save('failure.json', {'error': type(exc).__name__+': '+str(exc)[:512]}, failure_receipt=True)
        raise


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('role', choices=['worker','monitor'])
    p.add_argument('--mode', choices=['local','live'], required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--scratch', type=Path, required=True)
    p.add_argument('--environments', type=Path, required=True)
    p.add_argument('--started', type=float, required=True)
    p.add_argument('--seconds', type=float, required=True)
    p.add_argument('--reserve', type=float, required=True)
    p.add_argument('--fault', default='none')
    p.add_argument('--worker-pid', type=int)
    p.add_argument('--nonce')
    args = p.parse_args()
    if args.mode == 'live': require_live_authority()
    (worker if args.role=='worker' else monitor)(args)
